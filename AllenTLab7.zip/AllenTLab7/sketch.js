var superheroes = [
  "Superman",
  "Batman",
  "Spider-Man",
  "The Hulk",
  "Wolverine",
  "Black Widow",
  "Wonder Woman",
];

var myHeroes = [];
var myHeroesX = [];
var myHeroesY = [];

function setup() {
  createCanvas(600, 800);
  background(180);
  text(concat("Array 1:", superheroes), width / 10, height - 130);
  for (var i = 0; i < 5; i++) {
    var arrNum = Math.floor(random(0, superheroes.length));

    myHeroes.push(superheroes[arrNum]);
    superheroes.splice(arrNum, 1); //This splice is needed in order to stop duplications from occuring
    myHeroesX.push(random(10, width - 50));
    myHeroesY.push(random(10, height - 150));
  }
  console.log(myHeroes);
  for (var j = 0; j < myHeroes.length; j++) {
    text(myHeroes[j], myHeroesX[j], myHeroesY[j]);
  }
  textSize(12);
  text("The remaining heroes are: " + superheroes, 50, height - 20);

  text(concat("Array 2:", myHeroes), 10, height - 110);
  textWrap(WORD);
  text(concat("Random 1:", myHeroesX), 10, height - 90);
  text(concat("Random 2:", myHeroesY), 10, height - 70);
  text(concat("Random 1 & 2:", myHeroesX + myHeroesY), 10, height - 50);
}

function draw() {}
