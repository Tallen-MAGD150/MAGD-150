var arrNum = 600;

var christmasTree;
var snowfalkeImage;
var deer;

var sfX;
var sfY;

var snowfalkeNum = 600;
var snowfalkes = [];

//var intXDirection = 0;
//var intYDirection = 0;

function preload ()
{
  christmasTree = loadImage("/assets/Images/istockphoto-102854517-612x612.jpg");
  snowfalkeImage = loadImage("/assets/Images/snowflakeImage_1.png");
  deer = loadImage("/assets/Images/Deer - Copy.png");

}
function setup() {
  createCanvas(600, 600,);
  background(180);


  //christmasTree
  //https://media.istockphoto.com/id/1270144004/photo/christmas-tree.jpg?s=612x612&w=0&k=20&c=63BApHa7J176NqSc41oNcNrJf1ZOVZMkOheHP9hlncM=
 //Snowfalke
 //https://png.pngtree.com/png-vector/20230831/ourmid/pngtree-3d-rendering-snowflake-isolated-png-image_9192400.png
 //Deer
 //https://i.pinimg.com/474x/d6/a9/4f/d6a94f0e90ef6f37a359a58f8cff063a.jpg
 
   for (var i = 0; i < snowfalkeNum; i++) {
    sfY = random(-50, height - 1800);
    sfX = random(600, width - 600);
  snowfalkes[i] = new Snaowfall(sfX, sfY);
  console.log(i);
  }
 
 
  
}

function draw() {

    image(christmasTree,0,0,width,height);
	textAlign(CENTER, CENTER);
	textFont('Chopin Script');
	textSize(32);
	fill("RED");
    stroke(10);
	text("Happy Holidays", 155,200);
	text("Be Marry", width/2,height/6);
	

	
	for (var k = 0; k < arrNum; k++) {
		
		snowfalkes[k].display();
		snowfalkes[k].move();
		console.log(snowfalkes.x);

	}
	
	imageMode(CENTER);
	scale(0.05, 0.05);
	image(deer,mouseX*20, mouseY*20);
	scale(1.0,1.0);
	imageMode(CORNER);
}

class Snaowfall {
	
  constructor(x, y) {

	this.x = x;  
    this.y = y;
    this.speed = .5;
	this.size = random(10,50);// get random size snowflakes
  }

  display() {
    image(snowfalkeImage, this.x, this.y,this.size,this.size);
  }
  
    move() {
    this.y += this.speed;
	}
}