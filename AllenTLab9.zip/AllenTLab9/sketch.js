var deathStar;
var head;
function setup() {
  createCanvas(400, 400, WEBGL)

  deathStar = csg(() => sphere(50))
    .subtract(() => {
      translate(40, -40);
      sphere(25);
    })
    .union(() => sphere(40))
    .done();
	
	
////////////////////////////////////////////////////////////////////////////////
	head = csg(() => sphere(200))
	{
		sphere(25);
	}.done();
////////////////////////////////////////////////////////////////



}

function draw() {
  
  
  
  
  clear();
  orbitControl();
  noStroke();
  lights();
  model(deathStar);
  model(head);
  
  
  
  
}